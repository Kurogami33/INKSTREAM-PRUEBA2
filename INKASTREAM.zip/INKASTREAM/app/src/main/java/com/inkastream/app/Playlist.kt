package com.inkastream.app

import java.net.HttpURLConnection
import java.net.URL

enum class Kind { MOVIE, SERIES, LIVE }

data class Item(
    val name: String,
    val url: String,
    val logo: String,
    val group: String,
    val kind: Kind,
    val show: String = name,
)

object Playlist {
    private val attr = Regex("""([\w-]+)="([^"]*)"""")
    private val episode = Regex("""\s*[-–]?\s*[Ss]\d{1,2}\s*[Ee]\d{1,3}.*$""")

    fun download(url: String): String {
        val c = URL(url.trim().replace(" ", "")).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 60000
        c.setRequestProperty("User-Agent", "INKASTREAM/1.0")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    fun parse(text: String): List<Item> {
        val out = ArrayList<Item>()
        var meta: String? = null
        for (raw in text.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF") -> meta = line
                line.isNotEmpty() && !line.startsWith("#") && meta != null -> {
                    val a = attr.findAll(meta).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
                    val name = meta.substringAfterLast(",").trim().ifEmpty { a["tvg-name"] ?: "Sin título" }
                    val kind = when {
                        "/series/" in line -> Kind.SERIES
                        "/movie/" in line -> Kind.MOVIE
                        else -> Kind.LIVE
                    }
                    out += Item(
                        name = name,
                        url = line,
                        logo = a["tvg-logo"] ?: "",
                        group = a["group-title"] ?: "Otros",
                        kind = kind,
                        show = if (kind == Kind.SERIES) name.replace(episode, "").trim() else name,
                    )
                    meta = null
                }
            }
        }
        return out
    }
}
