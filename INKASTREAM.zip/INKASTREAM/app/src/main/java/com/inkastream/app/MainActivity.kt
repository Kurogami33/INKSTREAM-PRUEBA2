package com.inkastream.app

import android.content.Context
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

val Red = Color(0xFFE50914)
val Black = Color(0xFF0A0A0A)
val Panel = Color(0xFF181818)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Red, onPrimary = Color.White,
                    background = Black, surface = Panel,
                    onBackground = Color.White, onSurface = Color.White,
                )
            ) { Surface(Modifier.fillMaxSize(), color = Black) { App() } }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("inka", Context.MODE_PRIVATE) }
    var url by remember { mutableStateOf(prefs.getString("m3u", "") ?: "") }
    var items by remember { mutableStateOf<List<Item>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Item?>(null) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(url, reload) {
        if (url.isBlank()) return@LaunchedEffect
        loading = true; error = null
        try {
            items = withContext(Dispatchers.IO) { Playlist.parse(Playlist.download(url)) }
            if (items.isEmpty()) error = "La lista está vacía o no es válida"
        } catch (e: Exception) {
            error = "No se pudo cargar la lista: ${e.message}"
        }
        loading = false
    }

    if (playing != null) {
        Player(playing!!) { playing = null }
        return
    }
    if (url.isBlank() || (items.isEmpty() && !loading)) {
        Setup(url, error) { new ->
            prefs.edit().putString("m3u", new).apply()
            url = new; reload++
        }
        return
    }
    Home(items, loading, onPlay = { playing = it }, onReload = { reload++ }, onChange = {
        prefs.edit().remove("m3u").apply(); url = ""; items = emptyList()
    })
}

@Composable
fun Setup(current: String, error: String?, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(current) }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("INKASTREAM", color = Red, style = MaterialTheme.typography.displaySmall, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(8.dp))
        Text("Pega el enlace de tu lista M3U", color = Color.LightGray)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(
            value = text, onValueChange = { text = it },
            label = { Text("URL M3U") }, singleLine = false, modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Red, focusedLabelColor = Red, cursorColor = Red),
        )
        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Red) }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { onSave(text.trim()) }, enabled = text.isNotBlank(),
            colors = ButtonDefaults.buttonColors(containerColor = Red),
            modifier = Modifier.fillMaxWidth().height(50.dp),
        ) { Text("Cargar", fontWeight = FontWeight.Bold) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Home(items: List<Item>, loading: Boolean, onPlay: (Item) -> Unit, onReload: () -> Unit, onChange: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var group by remember { mutableStateOf<String?>(null) }
    var show by remember { mutableStateOf<String?>(null) }
    val kinds = listOf(Kind.MOVIE to "Películas", Kind.SERIES to "Series", Kind.LIVE to "TV")
    val kind = kinds[tab].first

    val ofKind = remember(items, kind) { items.filter { it.kind == kind } }
    val groups = remember(ofKind) { ofKind.map { it.group }.distinct().sorted() }
    val shown = remember(ofKind, query, group) {
        ofKind.filter { (group == null || it.group == group) && it.name.contains(query, true) }
    }
    val cards = remember(shown, kind) {
        if (kind == Kind.SERIES) shown.distinctBy { it.show } else shown
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("INKASTREAM", color = Red, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            TextButton(onClick = onReload) { Text("Actualizar", color = Color.White) }
            TextButton(onClick = onChange) { Text("Lista", color = Color.White) }
        }
        TabRow(selectedTabIndex = tab, containerColor = Black, contentColor = Red) {
            kinds.forEachIndexed { i, (_, label) ->
                Tab(selected = tab == i, onClick = { tab = i; group = null; query = "" }, text = { Text(label) })
            }
        }
        OutlinedTextField(
            value = query, onValueChange = { query = it }, singleLine = true,
            placeholder = { Text("Buscar") },
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Red, cursorColor = Red),
        )
        if (groups.isNotEmpty()) {
            androidx.compose.foundation.lazy.LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item { FilterChip(group == null, { group = null }, { Text("Todo") }, colors = chip()) }
                items(groups) { g -> FilterChip(group == g, { group = if (group == g) null else g }, { Text(g, maxLines = 1) }, colors = chip()) }
            }
        }
        if (loading) LinearProgressIndicator(Modifier.fillMaxWidth().padding(top = 8.dp), color = Red)
        LazyVerticalGrid(
            columns = GridCells.Adaptive(120.dp),
            contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(cards, key = { it.url }) { it ->
                Card(
                    onClick = { if (kind == Kind.SERIES) show = it.show else onPlay(it) },
                    colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(10.dp),
                ) {
                    AsyncImage(
                        model = it.logo, contentDescription = it.show, contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxWidth().aspectRatio(2f / 3f).background(Color(0xFF222222)),
                    )
                    Text(it.show, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(8.dp), style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    show?.let { s ->
        val eps = items.filter { it.kind == Kind.SERIES && it.show == s }
        AlertDialog(
            onDismissRequest = { show = null },
            containerColor = Panel,
            title = { Text(s, color = Red) },
            text = {
                LazyColumn {
                    items(eps) { e ->
                        Text(
                            e.name, modifier = Modifier.fillMaxWidth().clickable { show = null; onPlay(e) }.padding(vertical = 12.dp),
                        )
                        HorizontalDivider(color = Color(0xFF333333))
                    }
                }
            },
            confirmButton = { TextButton({ show = null }) { Text("Cerrar", color = Red) } },
        )
    }
}

@Composable
private fun chip() = FilterChipDefaults.filterChipColors(selectedContainerColor = Red, selectedLabelColor = Color.White)

@Composable
fun Player(item: Item, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val player = remember {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(item.url)); prepare(); playWhenReady = true
        }
    }
    DisposableEffect(Unit) { onDispose { player.release() } }
    BackHandler(onBack = onClose)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
        TextButton(onClick = onClose, modifier = Modifier.statusBarsPadding().align(Alignment.TopStart)) {
            Text("← ${item.show}", color = Color.White, maxLines = 1)
        }
    }
}
