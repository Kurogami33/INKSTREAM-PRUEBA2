# INKASTREAM
App Android (Kotlin + Jetpack Compose + Media3) en rojo y negro. Carga una lista M3U, separa Películas / Series / TV, con búsqueda, categorías y reproductor.

## Compilar
1. Abre la carpeta en Android Studio (Koala o superior) y deja que sincronice Gradle.
2. Run ▶ en un dispositivo, o Build > Build APK(s).
3. Al abrir la app, pega tu enlace M3U (se guarda solo en el teléfono).
